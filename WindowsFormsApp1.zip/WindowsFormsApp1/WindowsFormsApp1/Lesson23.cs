﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Lesson23 : Form
    {
        public Lesson23()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Button pressed!");
        }

        private void Lesson23_Load(object sender, EventArgs e)
        {
            button1.PerformClick();
        }
    }
}
