﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Lesson13 : Form
    {
        public Lesson13()
        {
            InitializeComponent();
        }

        private void Lesson13_Load(object sender, EventArgs e)
        {
            linkLabel1.Links[0].LinkData = "https://microsoft.com";
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Запускаем браузер и открываем в нем страницу.
            System.Diagnostics.Process.Start(e.Link.LinkData.ToString());

        }
    }
}
