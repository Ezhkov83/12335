﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Lesson1 lesson1 = new Lesson1();
            lesson1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Lesson2 lesson2 = new Lesson2();
            lesson2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Lesson3 lesson3 = new Lesson3();
            lesson3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Lesson4 lesson4 = new Lesson4();
            lesson4.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Lesson5 lesson5 = new Lesson5();
            lesson5.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Lesson6 lesson6 = new Lesson6();
            lesson6.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Lesson7 lesson7 = new Lesson7();
            lesson7.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Lesson8 lesson8 = new Lesson8();
            lesson8.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Lesson9 lesson9 = new Lesson9();
            lesson9.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Lesson10 lesson10 = new Lesson10();
            lesson10.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Lesson11 lesson11 = new Lesson11();
            lesson11.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Lesson12 lesson12 = new Lesson12();
            lesson12.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Lesson13 lesson13 = new Lesson13();
            lesson13.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Lesson14 lesson14 = new Lesson14();
            lesson14.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Lesson15 lesson15 = new Lesson15();
            lesson15.Show();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Lesson16 lesson16 = new Lesson16();
            lesson16.Show();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Lesson17 lesson17 = new Lesson17();
            lesson17.Show();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Lesson18 lesson18 = new Lesson18();
            lesson18.Show();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Lesson19 lesson19 = new Lesson19();
            lesson19.Show();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Lesson20 lesson20 = new Lesson20();
            lesson20.Show();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Lesson21 lesson21 = new Lesson21();
            lesson21.Show();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            Lesson22 lesson22 = new Lesson22();
            lesson22.Show();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            Lesson23 lesson23 = new Lesson23();
            lesson23.Show();
        }
    }
}
